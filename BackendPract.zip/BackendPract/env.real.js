// env.js

import path from "path"
import { fileURLToPath } from "url"

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

console.log("NODE_ENV:", process.env.NODE_ENV)
console.log("ENV PATH:", path.join(__dirname, ".env"))

if (process.env.NODE_ENV !== "production") {
  const dotenv = await import("dotenv")

  const result = dotenv.config({
    path: path.join(__dirname, ".env")
  })

  console.log("dotenv error:", result.error)
  console.log("MONGO_URI loaded:", Boolean(process.env.MONGO_URI))
}